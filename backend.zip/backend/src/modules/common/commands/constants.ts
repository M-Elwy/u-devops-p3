export const COMMAND_VALIDATOR_METADATA = '__commandValidator__';
